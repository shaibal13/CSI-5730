LIBRARY ieee;
USE ieee.std_logic_1164.all;

--simple entity that connects the SW switches to theLEDR lights

ENTITY part1 IS
	PORT(SW : IN STD_LOGIC_VECTOR(9 DOWNTO 0);
		LEDR : OUT STD_LOGIC_VECTOR(9 DOWNTO 0));
END part1;

ARCHITECTURE Behavior OF part1 IS
BEGIN
	LEDR <= SW;
END Behavior;